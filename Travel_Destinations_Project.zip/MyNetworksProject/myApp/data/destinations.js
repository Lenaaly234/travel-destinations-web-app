const destinations = [
  { name: "Paris", slug: "paris" },
  { name: "Rome", slug: "rome" },
  { name: "Bali Island", slug: "bali" },
  { name: "Santorini Island", slug: "santorini" },
  { name: "Inca Trail to Machu Picchu", slug: "inca" },
  { name: "Annapurna Circuit", slug: "annapurna" }
];

module.exports = destinations;
